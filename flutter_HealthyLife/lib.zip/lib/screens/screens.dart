export 'home_screen/home_screen.dart';
export 'hidration_screen.dart';
export 'diet_screen.dart';
export 'exercise_screen.dart';
export 'sleep_screen.dart';
export 'settings_screen.dart';
export 'login_screen.dart';
export 'register_screen.dart';
export 'profile_screen.dart';

// Aquí están las exportaciones